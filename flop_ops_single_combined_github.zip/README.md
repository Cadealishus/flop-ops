# Flop Ops Single-File Build

Upload `index.html` to the root of the `flop-ops` GitHub repo.

This version keeps the menu and playable game in one combined file, so it avoids broken folder/iframe paths from separated files.

Open with GitHub Pages:
https://cadealishus.github.io/flop-ops/

Or load through jsDelivr:
https://cdn.jsdelivr.net/gh/Cadealishus/flop-ops@main/index.html

If jsDelivr caches an old copy, add a cache buster like `?v=2`.
